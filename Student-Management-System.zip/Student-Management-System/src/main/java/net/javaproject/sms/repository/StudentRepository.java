package net.javaproject.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaproject.sms.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long>{

}