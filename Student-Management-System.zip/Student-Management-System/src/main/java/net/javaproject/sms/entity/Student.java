package net.javaproject.sms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "first_name", nullable = false)
	private String FirstName;
	
	@Column(name = "roll_no")
	private String RollNo;
	
	@Column(name = "email")
	private String email;
	
	public Student() {
		
	}
	
	public Student(String FirstName, String RollNo, String email) {
		super();
		this.FirstName = FirstName;
		this.RollNo = RollNo;
		this.email = email;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}
	public String getRollNo() {
		return RollNo;
	}
	public void setRollNo(String RollNo) {
		this.RollNo = RollNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}